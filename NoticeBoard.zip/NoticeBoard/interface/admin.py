from django.contrib import admin
from interface.models import *
# Register your models here.
admin.site.register(Poster)