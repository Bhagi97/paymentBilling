from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from django.http import JsonResponse

from interface.models import *

import pdb
import ast
import datetime

def index(request):
    if request.method == "POST":
        type = request.POST.get('type')
        if type=="Poster":
            kwargs = {"name" : request.POST.get('filename', ''),
                      "image" : request.FILES['posterToUpload'],
                      "uploader" : request.user,
                      }
            poster = Poster(**kwargs)
            poster.save()
    context = {}
    context['posters'] = Poster.objects.all()
    template = loader.get_template('interface/index.html')
    return HttpResponse(template.render(context, request))


def getposterdetails(request):
    data={}
    data['poster'] = Poster.objects.filter(id=request.GET['pid']).values()[0]
    data['poster']['created_at'] = datetime.datetime.strftime(data['poster']['created_at'],"%d/%m/%Y")
    data['success'] = 1
    return JsonResponse(data)

def updateposter(request):
    data={}
    p = Poster.objects.get(id=int(request.GET['id']))
    p.name = request.GET['data[filename]']
    p.show = True if request.GET.get('data[show]','off')=='on' else False
    p.save()
    data['success'] = 1
    return JsonResponse(data)


def deleteposter(request):
    data={}
    p = Poster.objects.filter(id=int(request.GET['id']))
    if len(p)>0:
        data['success'] = 1
        p.delete()
    else:
        data['success'] = 0
    return JsonResponse(data)